import {TestSearchPipe} from './test-search.pipe';

describe('TestSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new TestSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
