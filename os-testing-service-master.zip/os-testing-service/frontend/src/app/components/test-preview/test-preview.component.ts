import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-preview',
  templateUrl: './test-preview.component.html',
  styleUrls: ['./test-preview.component.scss']
})
export class TestPreviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
