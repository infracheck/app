declare var $ENV: Env;

interface Env {
  SERVER: string;
}
