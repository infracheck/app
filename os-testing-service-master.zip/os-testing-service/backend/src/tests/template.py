import pytest

'''# README Dont delete the Inline-Comments `# --- DEFINITION ---` and `# --- TEST ---`. They are used as markers by 
the test builder to create the final test. 

This is a template for a test. You can use it to create your own tests. You can delete all comments in production, 
except the 'definition'. Please fill it to make sure everybody knows what your test does. 
'''

# --- DEFINITION ---

# This is the data placeholder object
DATAPH = {
    "example_key": [],
    "another_key": [],
}

"""
Name of your test
============

## Description
Write a short description what your test is doing.
        
## Examples
```
# Write some examples, how the test data could look like.
{
    "example_key": ['to', 'store', 'useless', 'stuff', 'in', 'this', 'list'],
    "another_key": ['google.de', 'proficom.de'],
}
```

## Plugin Version
0.1.0

[Use semantic versioning here](https://semver.org/)

## Author
Write who to blame for bad test (or celebrate for good ones).
Martin Welcker <mwelcker@proficom.de>
"""


# --- TEST ---

# Use parametrize if you want to run multiple tests with a list of values.
@pytest.mark.parametrize("list_value", DATAPH["example_key"])
# Each test function should follow the naming scheme 'test_<NAME>'
# The 'host' variable is used to access the 'testinfra' features
def test_your_custom_test_name(host, list_value):
    assert list_value == "useless"
    assert 0 == 0
