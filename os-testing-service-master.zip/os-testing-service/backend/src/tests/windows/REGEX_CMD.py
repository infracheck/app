import pytest

# --- DEFINITION ---
DATAPH = {
    "cmd": "string",
    "regex": "string"
}

"""
# Run command and check output for regex [Windows + Linux]
---
## Description:
Runs a command and compares the output with the given regular expression. This test is compatible with linux and windows.


[Testinfra Docs](
https://testinfra.readthedocs.io/en/latest/modules.html#testinfra.host.Host.run) 
        
## Examples:
```json
# Check if echo works
{
    "id":"WIN_RUN",
    "data":{
        "cmd": "echo test",
        "regex": "test"
        }
}
```

## Plugin Version
0.1.0


## Author
Martin Welcker <mwelcker@proficom.de>
"""


# --- TEST ---
def validate_data():
    from jsonschema import validate
    regex_cmd_data_schema = {
        "type": "object",
        "properties": {
            "cmd": {"type": "string"},
            "regex": {"type": "string"}
        },
        "additionalProperties": False
    }

    if validate(instance=DATAPH, schema=regex_cmd_data_schema):
        raise TypeError('Date for REGEX_CMD is invalid')


def test_regex_cmd(host):
    validate_data()
    import re
    out = host.run(DATAPH['cmd']).stdout

    assert re.search(DATAPH['regex'], out), "Output: '" + out + "'does not contain regex: '" + DATAPH['regex'] + "'"
