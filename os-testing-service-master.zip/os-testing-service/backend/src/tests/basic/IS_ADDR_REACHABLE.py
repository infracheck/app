import pytest

# --- DEFINITION ---
DATAPH = {
    "addr_list": "string[]"
}

"""
# Is adress reachable [Linux]
---

## Description:
This test checks if a list of hosts is reachable.

[Testinfra Docs](
https://testinfra.readthedocs.io/en/latest/modules.html#testinfra.modules.addr.Addr) 
        
## Examples:
```json
# Checking a list of hosts
{"addr_list": ["google.de", "proficom.de"]}

# Checking for a single hosts
{"addr_list": ["google.de"]}

# Checks for 
{"addr_list": ["192.168.0.10", "127.0.0.1"]}
```

## Plugin Version
0.1.1


## Author
Martin Welcker <mwelcker@proficom.de>
"""


# --- TEST ---
@pytest.mark.parametrize("addr", DATAPH["addr_list"])
def test_host_addr_reachable(host, addr):
    curr_addr = host.addr(addr)
    assert curr_addr.is_resolvable
    assert curr_addr.is_reachable
