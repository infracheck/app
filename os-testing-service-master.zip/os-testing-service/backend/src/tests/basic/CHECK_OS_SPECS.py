import pytest

# --- DEFINITION ---
DATAPH = {
    "type": "string",
    "distribution": "string",
    "release": "string",
    "codename": "string"
}

"""
# Checks specs of operating system [Linux]
---

## Description: 
This test can check for various specs of the operating system. It can be used to check the `type`, 
`distribution`, `release` and `codename` of the hosts os. 

[Testinfra Docs](
https://testinfra.readthedocs.io/en/latest/modules.html#testinfra.modules.systeminfo.SystemInfo) 
        
## Examples:
```json
# Checking a list of hosts
{
    "type": "linux",
    "distribution": "debian",
    "release": "7.8",
    "codename": "wheezy"
}
```

## Plugin Version
0.1.1

## Author
Martin Welcker <mwelcker@proficom.de>
"""


# --- TEST ---
def test_os_type(host):
    if DATAPH["type"]:
        assert host.system_info.type == DATAPH["type"]


def test_os_distribution(host):
    if DATAPH["distribution"]:
        assert host.system_info.distribution == DATAPH["distribution"]


def test_os_release(host):
    if DATAPH["release"]:
        assert host.system_info.release == DATAPH["release"]


def test_os_codename(host):
    if DATAPH["codename"]:
        assert host.system_info.codename == DATAPH["codename"]
