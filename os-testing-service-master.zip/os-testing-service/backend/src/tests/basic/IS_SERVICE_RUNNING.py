import pytest

# --- DEFINITION ---
DATAPH = {
    "services": "string[]"
}

"""
.. todo:: It should be possible to check for different service states
# Is adress reachable [Linux]
---

## Description:
Check for running services. 

[Testinfra Docs](
https://testinfra.readthedocs.io/en/latest/modules.html#testinfra.modules.service.Service) 
        
## Examples:
```json
# Checking a list of services
{
    "services": ["nginx", "apache2"]
}
```

## Plugin Version
0.1.0

## Author
Martin Welcker <mwelcker@proficom.de>
"""


# --- TEST ---
@pytest.mark.parametrize("service", DATAPH["services"])
def test_service_running(host, service):
    curr_service = host.service(service)
    assert curr_service.is_running
    assert curr_service.is_enabled
