import yaml
from flask import request, jsonify

from src.app.PresetApi import PresetApi
from src.app.ResultApi import ResultApi
from src.app.TestApi import TestApi
from src.app.services.Logger import Logger
from src.app.test_process.TestService import TestService


def init_routes(app):
    @app.route('/check')
    def health_check():
        return jsonify({"serverStatus": "running"})

    @app.route('/preset', methods=['POST'])
    def save_preset():
        try:
            if request.content_type.startswith('application/json'):
                data = request.get_json()
            else:
                data = yaml.safe_load(request.get_data())
            return PresetApi().save_preset(data)
        except Exception as e:
            return str(e), 500

    @app.route('/preset/<path:test_id>', methods=['DELETE'])
    def delete_preset(test_id):
        try:
            return PresetApi().delete_preset(test_id)
        except Exception as e:
            return str(e), 500

    @app.route('/preset/<path:test_id>')
    def get_preset(test_id):
        try:
            return PresetApi().get_preset(test_id)
        except Exception as e:
            return str(e) + '  ' + test_id, 500

    @app.route('/presets')
    def get_all_presets():
        try:
            return PresetApi().get_all_presets()
        except Exception as e:
            return str(e), 500

    @app.route('/tests')
    def list_tests():
        t = TestApi()
        return jsonify(t.get_detailed_test_list())

    @app.route('/latest_tests/<path:result_id>')
    def list_latest_test_result(result_id):
        trs = ResultApi()
        results = trs.get_test_result(result_id)
        return jsonify(results)

    @app.route('/latest_tests')
    def list_latest_test_results():
        trs = ResultApi()
        results = trs.get_latest_results()
        if len(results) >= 10:
            return jsonify(results[0:10])
        return jsonify(results)

    @app.errorhandler(404)
    def not_found(error):
        return error, 404

    @app.route('/run', methods=['POST'])
    def run_test_flow():
        Logger().info('Start test')
        try:
            # Supports YAML and JSON request body
            #  If content_type = application/json --> JSON
            #  If content_type != application/json --> YAML
            if request.content_type.startswith('application/json'):
                data = request.get_json()
            else:
                # Convert incoming yaml to json
                data = yaml.safe_load(request.get_data())

            return TestService(data).start_test_process()
        except Exception as e:
            return str(e), 500
