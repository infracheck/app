import datetime
import json
import os
import time
import xml.dom.minidom

from src.app.services.Config import Config
from src.app.utils.KeyRegistrationHelper import KeyRegistrationHelper


class TestRunner:

    def __init__(self, uid, test_settings):
        self.test_settings = test_settings
        self.uid = uid
        self.hosts = self.test_settings['hosts']
        self.auth_user = self.test_settings['user']
        self.target_os = self.test_settings['target_os']
        self.pw = self.test_settings['password']
        self.result = ''
        self.ssh_key_helper = KeyRegistrationHelper(self.auth_user, self.pw)

    def launch_test_flow(self):
        start_time = time.time()
        self.register_ssh_keys()
        self.create_test_command_and_launch_test()
        self.clean_ssh_keys()
        return self.convert_result_to_csv(start_time)

    def create_test_command_and_launch_test(self):
        config_string = F"--junit-xml={Config.data['resultFolder']}{self.uid}.xml"
        host_string = self.create_hosts_string()
        cmd = F"py.test {Config.data['testSetFolder']}test{self.uid}.py {host_string} {config_string} "
        os.system(cmd)

    def create_hosts_string(self):
        if self.target_os == 'linux':
            hosts_with_auth = list(
                map(lambda host: F'ssh://{self.auth_user}@{host}', self.hosts
                    )
            )
            host_string = ','.join(map(str, hosts_with_auth))
            os_specific_cmd_part = F"--ssh-identity-file='key/id_rsa' --hosts='{host_string}'"
        else:
            hosts_with_auth = list(
                map(lambda host:
                    F"winrm://{self.auth_user}:{self.test_settings['password']}@{host}:5985?no_ssl=true&no_verify_ssl=true",
                    self.hosts
                    )
            )
            host_string = ','.join(map(str, hosts_with_auth))
            os_specific_cmd_part = F"--hosts='{host_string}'"
        return os_specific_cmd_part

        # Create a csv report that is saved in a file and send as api response

    def convert_result_to_csv(self, start_time):
        xml_file = Config.data['resultFolder'] + self.uid + '.xml'
        input_file = xml.dom.minidom.parse(xml_file)
        result = {
            "id": self.uid,
            "jsonOutput": '/results/' + self.uid + ".json",
            "name": self.test_settings['name'],
            "description": self.test_settings['description'],
            "date": datetime.datetime.today().strftime('%m/%d/%Y-%H:%M'),
            "processing_time": time.time() - start_time
        }

        testsuite_keys = [
            "errors",
            "failures",
            "skipped",
            "tests",
            "time"
        ]

        testsuite = input_file.getElementsByTagName("testsuite")[0]
        for key in testsuite_keys:
            result[key] = testsuite.getAttribute(key)

        result["testset"] = []
        test_cases = input_file.getElementsByTagName("testcase")
        for test in test_cases:
            test_data = {
                "name": test.getAttribute("name"),
                "host": test.getAttribute("name").split('[')[1].split(']')[0].rsplit('-', 1)[0],
                "time": test.getAttribute("time")
            }
            if test.getElementsByTagName("failure"):
                success = False
                test_data["message"] = test.getElementsByTagName("failure")[0].getAttribute("message")
            else:
                success = True

            test_data["success"] = success
            result["testset"].append(test_data)
        self.write_json_to_file(result, Config.data['resultFolder'] + self.uid)
        return result

    def write_json_to_file(self, data, file):
        with open(file + '.json', 'w') as outfile:
            json.dump(data, outfile)

    def register_ssh_keys(self):
        if self.test_settings['target_os'] == 'linux':
            for host in self.hosts:
                self.ssh_key_helper.register_ssh_key_on_host(host)
        pass

    def clean_ssh_keys(self):
        if self.test_settings['target_os'] == 'linux':
            for host in self.hosts:
                self.ssh_key_helper.remove_ssh_key(host)
        pass
