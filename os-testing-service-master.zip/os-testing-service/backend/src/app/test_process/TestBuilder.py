import json

from src.app.PresetApi import PresetApi
from src.app.TestApi import TestApi
from src.app.services.Config import Config


class TestBuilder:

    def __init__(self, uid, test_data):
        self.uid = uid
        self.test_data = test_data
        self.test_code = []

    # function creates a testfile containing a header and a body
    #  The body will be build traversing the array of tests which is defined in the request data
    #  For each entry the containing test gets added to the final testfile
    def generate_test_code(self):
        # Include presets
        if 'presets' in self.test_data:
            self.test_data = self.resolve_presets(self.test_data)

        self.test_code = self.generate_head() + self.generate_body()
        filename = self.write_code_to_file()

        return filename

    def generate_head(self):
        return [
            'import pytest \n',
            'data = {} ',
            '\n\n'
        ]

    def generate_body(self):
        id_counter = 1
        body = []
        for test in self.test_data['testset']:
            current_key = 'data["' + test['id'] + '"]'
            current_data = json.dumps(test['data'])

            # Write data assignment
            body.append(current_key + ' = ' + current_data)
            # Load test case  and
            #  replace the data placeholder inside each test, DATAPH -> [real data object]
            #  replace test function name -> Add id to each test function
            t = TestApi()
            test_case = t.get_test(test['id']) \
                .replace('DATAPH', current_key) \
                .replace('def test_', F"def test_{id_counter}_")
            body.append(test_case.split('# --- TEST ---')[1] + '\n\n')
            id_counter += 1
        return body

    # Load desired presets and include their tests into the testfile body
    def resolve_presets(self, test_body):
        presets = test_body['presets']
        for preset in presets:
            resolved_presets = json.loads(PresetApi().get_preset(preset['id']))
            for test in resolved_presets:
                test_body['testset'] = test_body['testset'] + test['testset']
        return test_body

    def write_code_to_file(self):
        file_name = F"{Config.data['testSetFolder']}test{self.uid}.py"
        file = open(file_name, 'w+')
        file.writelines(self.test_code)
        return file_name
