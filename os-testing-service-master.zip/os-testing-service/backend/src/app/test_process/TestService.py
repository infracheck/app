import uuid

from src.app.services.Logger import Logger
from src.app.test_process.TestBuilder import TestBuilder
from src.app.test_process.TestRunner import TestRunner
from src.app.utils.Validator import Validator


class TestService:

    def __init__(self, test_data):
        Validator.validate_test_body(test_data)
        uid = uuid.uuid4().hex
        self.test_builder = TestBuilder(uid, test_data)
        self.test_runner = TestRunner(uid, test_data['settings'])

    def start_test_process(self):
        file_name = self.test_builder.generate_test_code()
        Logger().info(F'Test code was generated at {file_name}')

        return self.test_runner.launch_test_flow()
