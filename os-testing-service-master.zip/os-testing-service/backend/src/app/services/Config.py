import json


# Singleton pattern
class Config(object):
    __instance = None
    data = json.load(open('config/default.json'))

    def __new__(cls, val):
        if Config.__instance is None:
            Config.__instance = object.__new__(cls)
        Config.__instance.val = val
        return Config.__instance
