from flask import current_app


class Logger:
    __instance = None
    app = current_app

    def __new__(cls):
        if Logger.__instance is None:
            Logger.__instance = object.__new__(cls)
        return Logger.__instance

    def info(self, msg):
        self.app.logger.info(msg)

    def debug(self, msg):
        self.app.logger.info(msg)
