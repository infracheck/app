# Singleton pattern
# TODO: Create class


class Database(object):
    __instance = None

    def __new__(cls, val):
        if Database.__instance is None:
            Database.__instance = object.__new__(cls)
        Database.__instance.val = val
        return Database.__instance
