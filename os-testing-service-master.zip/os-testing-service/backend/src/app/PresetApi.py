from bson.json_util import dumps, loads
from bson.objectid import ObjectId
from pymongo import MongoClient

from src.app.services.Logger import Logger


class PresetApi:
    client = MongoClient('172.16.20.90', 27017)
    db = client['testsets']
    test_sets = db.testsets
    __instance = None

    def __new__(cls):
        if PresetApi.__instance is None:
            PresetApi.__instance = object.__new__(cls)
        return PresetApi.__instance

    def save_preset(self, data):
        if loads(self.get_preset(data['id'])):
            Logger().info('Overwrite')
            query = {"id": data['id']}
            new_values = {"$set": {
                "testset": data['testset'],
                "description": data['description']}}
            result = self.test_sets.update_one(query, new_values).modified_count
        else:
            result = self.test_sets.insert_one(data).inserted_id
        return dumps(result)

    def get_preset(self, test_id):
        query = {"id": test_id}
        return dumps(self.test_sets.find(query, {"_id": 1, "id": 1, "testset": 1, "description": 1}))

    def get_all_presets(self):
        return dumps(self.test_sets.find({}, {"_id": 1, "id": 1, "testset": 1, "description": 1}))

    def delete_preset(self, _id):
        myquery = {"_id": ObjectId(_id)}
        return dumps(self.test_sets.delete_one(myquery).deleted_count)
