import pexpect


class KeyRegistrationHelper:

    def __init__(self, user, password):
        self.user = user
        self.pw = password
        self.logs = open('register-ssh-logs.txt', 'wb')

    # used for linux ssh connections only
    def register_ssh_key_on_host(self, host):
        self.register_key(host)
        self.test_ssh_with_key(host)

    # Use ssh-copy-id to register the local key on a remote host
    def register_key(self, ip):
        child = pexpect.spawn('ssh-copy-id -i key/id_rsa ' + self.user + '@' + ip + ' -o StrictHostKeyChecking=no -f')
        child.logfile_read = self.logs

        i = child.expect(['password'])
        if i == 0:
            print('Wants to know PW')
        else:
            child.sendline('yes')

        added_key = False
        while not added_key:
            child.sendline(self.pw)
            i = child.expect(['added:', 'denied'])
            if i == 0:  # Key successfully added
                added_key = True
            if i == 1:  # Permission denied
                child.close()
                raise PermissionError(
                    'SSH connection denied because of permission issues. Check your password and retry.')
        child.close()

    # This function tries to connect to the host via ssh and closes the connection afterwards
    def test_ssh_with_key(self, ip):
        child = pexpect.spawn("ssh -i key/id_rsa -o 'StrictHostKeyChecking=no'  " + self.user + "@" + ip)
        child.logfile_read = open('register-ssh-logs.txt', 'wb')

        i = child.expect(['login:'])
        if i == 0:
            child.sendline('exit')
            i = child.expect(['closed'])
            if i == 0:
                print("Logout successful")
            else:
                raise ConnectionError('Logout after ssh failed. Have a look at the logs.')
        else:
            raise ConnectionError('Could not login via ssh. See logs for help.')
        child.close()

    # This function tries to connect to the host via ssh and closes the connection afterwards
    def remove_ssh_key(self, ip):
        child = pexpect.spawn("ssh -i key/id_rsa -o 'StrictHostKeyChecking=no'  " + self.user + "@" + ip)
        child.logfile_read = open('register-ssh-logs.txt', 'wb')

        i = child.expect(['login:'])
        if i == 0:
            child.sendline(self.ssh_key_delete_cmd())
            i = child.expect(['closed'])
            if i == 0:
                print("Logout successful")
            else:
                raise ConnectionError('Problem overwriting authorized keys.')
        else:
            raise ConnectionError('Could not login via ssh. See logs for help.')
        child.close()

    def ssh_key_delete_cmd(self):
        key = open("key/id_rsa.pub", "r").read().rstrip()

        # split the key in its three parts (ssh-rsa, content, name)
        key_parts = key.split(' ')

        # TODO: Command should also replace newline
        return F"sed -i.bak '/{key_parts[0]}.*{key_parts[2]}/ g' .ssh/authorized_keys && exit"
