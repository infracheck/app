from jsonschema import validate

from src.app.TestApi import TestApi


class Validator:

    # Validate the test_body and delivers good error feedback
    #  restrictively checks the complete json object
    #  checks if test id and os type is valid
    @staticmethod
    def validate_test_body(body):
        t = TestApi()
        check_valid_tests_regex = F"(^{'$|^'.join(t.get_test_list())}$)"
        scheme = {
            "type": "object",
            "required": ["settings", "testset"],
            "properties": {
                "settings": {"type": "object",
                             "required": ["name", "description", "hosts", "user", "target_os", "password"],
                             "additionalProperties": False,
                             "properties": {
                                 "name": {"type": "string"},
                                 "description": {"type": "string"},
                                 "hosts": {"type": "array",
                                           "additionalProperties": False,
                                           "minItems": 1,
                                           "items": {
                                               "type": "string"
                                           }
                                           },
                                 "user": {"type": "string"},
                                 "target_os": {"type": "string",
                                               "pattern": "(^linux$|^windows$)"
                                               },
                                 "password": {"type": "string"}
                             }},
                "testset": {"type": "array",
                            "minItems": 1,
                            "items": {
                                "type": "object",
                                "additionalProperties": False,
                                "required": ["id", "data"],
                                "properties": {
                                    "id": {"type": "string",
                                           "pattern": check_valid_tests_regex},
                                    "data": {"type": "object"}
                                }
                            }},
                "presets": {"type": "array",
                            "items": {
                                "type": "object",
                                "additionalProperties": False,
                                "properties": {
                                    "id": {"type": "string"},
                                }
                            }}
            },
            "additionalProperties": False
        }

        result = validate(instance=body, schema=scheme)
        if result:
            raise TypeError(result)
