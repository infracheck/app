import os
from datetime import datetime
import json


class ResultApi:
    resultFolder = 'html/results'

    def get_latest_results(self):
        result = []
        test_list = self.get_latest_result_ids()
        for test_id in test_list:
            result.append(self.get_test_result(test_id))

        sorted_results = sorted(
            result,
            key=lambda x: datetime.strptime(x['date'], '%m/%d/%Y-%H:%M'), reverse=True
        )

        return sorted_results

    def get_latest_result_ids(self):
        result = []
        for root, dirs, files in os.walk(self.resultFolder):
            for filename in files:
                if filename.split('.')[-1] == 'json':
                    result.append(filename.replace('.json', ''))
        return result

    def get_test_result(self, result_id):
        result_filename = result_id + '.json'
        for root, dirs, files in os.walk(self.resultFolder):
            for filename in files:
                if result_filename == filename:
                    test_case = open(os.path.join(root, filename)).read()
                    return json.loads(test_case)
        raise FileNotFoundError('test id not found. Please check for typos and try again. ')
