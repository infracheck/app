import os
import re
from json import loads


class TestApi:
    testFolder = 'src/tests'

    def get_test_list(self):
        result = []
        for root, dirs, files in os.walk(self.testFolder):
            for filename in files:
                if re.match('.*[A-Z].py', filename):
                    result.append(filename.replace('.py', ''))
        return result

    def get_detailed_test_list(self):
        result = []
        for root, dirs, files in os.walk(self.testFolder):
            for filename in files:
                if re.match('.*[A-Z].py', filename):
                    # Test found
                    directory = os.path.dirname(os.path.join(root, filename)).split('/')[2]
                    test_id = filename.replace('.py', '')
                    test_file = self.get_test(test_id)
                    test_description = test_file.split('"""')[1].split('# --- TEST ---')[0]
                    test_code = test_file.split('# --- TEST ---')[1]
                    input_syntax = test_file.split('DATAPH = ')[1].split('"""')[0]

                    result.append(
                        {
                            'id': filename.replace('.py', ''),
                            'description': test_description,
                            'code': test_code,
                            'directory': directory,
                            'input': loads(input_syntax)
                        }
                    )
        return result

    def get_test(self, test_id):
        test_filename = test_id + '.py'
        for root, dirs, files in os.walk(self.testFolder):
            for filename in files:
                if test_filename == filename:
                    test_case = open(os.path.join(root, filename)).read()
                    return test_case
        raise FileNotFoundError('test id not found. Please check for typos and try again. ')
