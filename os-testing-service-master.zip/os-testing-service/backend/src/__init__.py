import logging
import os

from flask import Flask
from flask_cors import CORS

from src.router import init_routes


def create_app():
    # Initialize flask
    app = Flask(__name__)
    init_routes(app)

    logging.basicConfig(level=logging.DEBUG)
    cors = CORS(app)
    app.config['CORS_HEADERS'] = 'Content-Type'

    # Create folder for results
    if not os.path.exists('html/results'):
        os.makedirs('html/results')

    # Create folder for testfiles
    if not os.path.exists('testset/'):
        os.makedirs('testset/')

    return app
