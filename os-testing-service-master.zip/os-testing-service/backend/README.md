## Perquisites
Make sure at least Python 3.5 is installed (don't mind if you use docker).


## Do before start
1. Create key on test-machine (computer where this code is)
``
$ ssh-keygen -t rsa
``

2. Add this key (the public key) to the known hosts list on all machines that should be tested.
``
$ ssh-copy-id USERNAME@MCHINE_IP
``

3. Run the tests


## Starting the service


````
// Run the following commands in the project directory
export FLASK_APP=src

// To change the environment config do
FLASK_ENV=development

// Run the app
python -m flask run

// Run on server
flask run --host="0.0.0.0" --port=8080
````


## Create the documentation
You can create the documentation with the following command: 
````
pdoc --html src --force
````
You normally don't need to do this by hand, because the docs get generated automatically when the service starts. The only purpose using this command manually is to check, how the docs look before starting the whole service.

## Docker
It is recommended to run this server inside its docker container. All you need to do is to start the 'docker-compose' and to add a ssh-key into the volume.

```
sudo docker-compose up -d
```

## JSON Example

````json
{
    "name": "Docker testing",
    "description": "",
    "settings": {
      "hosts": [
        "localhost"
      ],
      "user": "mwelcker",
      "private_key": "PRIVATE_SSH_KEY"
    },
    "testset": [
      {
        "id": "IS_ADDR_REACHABLE",
        "data": {
          "addr_list": ["localhost", "googldasdadasdadde.de"]
        }
      }
    ]
}
````