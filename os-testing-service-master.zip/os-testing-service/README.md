![alt text](frontend/src/assets/proficomlogo.png)
# OS-TESTING TOOL
> This tool provides you easy operation system testing. Launch predefined parameterizable tests on as many hosts as you want. 


## Links
- 👉 [Demo Application](http://172.16.20.90/)
- 🌟 The Company behind: [Profi.com AG](https://www.proficom.de/)

> WIP
> - 📘 Documentation: [Docs](docs/README.md) 

## Features

* **Plugin principle:** create your own test cases or use predefined sets
* **No Coding needed:** Create complex tests without a single line of code
* **Multiple platforms:** Windows Server and Linux support

## Getting Started
### Docker
I recommend to start this application with `docker-compose`. For that, please do the following:
- Clone this repository

- Be sure you have ``docker`` and ``docker-compose`` installed

- Configure the address of your backend inside the ``docker-compose.yml``:
 
```yaml
  args:
    - BACKEND=http://localhost:9000 
```

- **Build and start the container!**

```console
docker-compose build && docker-compose up -d
```

### Without Docker
- 📘 [Frontend](frontend/README.md) 
- 📘 [Backend](backend/README.md) 

## Versioning
We use [SemVer](http://semver.org/) for versioning. For the versions available, see the [releases on this repository](https://git.lab.proficom.de/mwelcker/os-testing-service/releases). 

## Built With
* [Angular](https://angular.io/) - Frontend framework
* [Typescript](https://www.typescriptlang.org/) - The Javascript Superset (Frontend + Backend)
* [NPM](https://www.npmjs.com/) - Dependency Management
* [Python3](https://docs.python.org/3/) - Backend framework
* [Flask](https://palletsprojects.com/p/flask/) - Python WSGI framework
* [Testinfra](https://testinfra.readthedocs.io/en/latest/) - Python OS testing framework
* [MongoDB](https://www.mongodb.com/de) - Database to store test presets
* [Docker](https://www.docker.com/) - Container system


## Authors
Feel free to contact:
* **Martin Welcker** - *Application Development* - [GitHub](https://github.com/martinwelcker)

## License
TODO
